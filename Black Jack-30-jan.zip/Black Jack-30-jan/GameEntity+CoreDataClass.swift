//
//  GameEntity+CoreDataClass.swift
//  Black Jack
//
//  Created by user252256 on 1/3/24.
//
//

import Foundation
import CoreData

@objc(GameEntity)
public class MyGameEntity: NSManagedObject {

}
