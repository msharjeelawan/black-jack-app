//
//  Game_Result_Model.swift
//  Black Jack
//
//  Created by user252256 on 1/3/24.
//

import Foundation
