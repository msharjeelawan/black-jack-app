//
//  ResultRepository.swift
//  Black Jack
//
//  Created by user252256 on 1/4/24.
//

import Foundation

class ResultRepository {
    
    func getAllGameResult(persistenceController: PersistenceController) -> [GameEntity] {
        let context = persistenceController.container.viewContext
        let games = GameEntity.getAllGameResults(context: context)
        print("total game: \(games.count)")
        return games
//        for game in games{
//            print("game id: \(game.game_id)")
//
//        }
    }
    
    func calculateRounds(of game: GameEntity) -> [String:Int] {
        var win :Int = 0, loss = 0, tie = 0, totalRounds = 0
        
        if let rounds = game.round_relationship {
            totalRounds = rounds.count
            //print("game round: \(rounds.count)")
            for round in rounds {
                if let roundEntity = round as? RoundEntity {
                    // Access individual round properties
                   // print("Game ID: \(game.game_id), Round ID: \(roundEntity.round_id), Player Score: \(roundEntity.player_score), Dealer Score: \(roundEntity.dealer_score)")
                    
                    let playerScore = roundEntity.player_score
                    let dealerScore = roundEntity.dealer_score
                    let isBust = roundEntity.is_bust
                    
                    if isBust == true {
                        // if round has bust then lower score player will win
                        if playerScore < dealerScore {
                            // player win
                            win = win + 1
                        }else if dealerScore < playerScore {
                            // player loss
                            loss = loss + 1
                        }
                    }else {
                        //here no bust, so higer score player will win
                        if playerScore > dealerScore {
                            // player win
                            win = win + 1
                        }else if dealerScore > playerScore && isBust == false {
                            // player loss
                            loss = loss + 1
                        }else if playerScore == dealerScore && isBust == false {
                            // tie
                            tie = tie + 1
                        }
                    }
                    
                }
            }
        }
        var gameResult: [String:Int] = [:]
        gameResult["game_no"] = Int(game.game_id)
        gameResult["win"] = win
        gameResult["loss"] = loss
        gameResult["tie"] = tie
        gameResult["rounds"] = totalRounds
        
        return gameResult
    }
    
}
