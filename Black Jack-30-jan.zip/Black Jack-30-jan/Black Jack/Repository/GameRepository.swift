//
//  GameRepository.swift
//  Black Jack App
//
//  Created by user252256 on 12/29/23.
//

import Foundation
import CoreData

class GameRepository {
    
    private let gameService = GameService()
    private var gameEntity: GameEntity?
    static var playerName = ""
  
    
    //create new deck using api
    func createNewDeck() async throws {
       try await gameService.createNewDeck()
    }
    
    //to avoid from api calls multiple time, draw all cards from deck in single api call
    func drawCard() async throws -> DrawCardResponse{
    
       return try await gameService.drawCard()
    }
    
    func shuffleDeck() async throws -> ShuffleDeckResponse{
        return try await gameService.shuffleCard()
    }
    
    func createNewGameEntity(persistenceController: PersistenceController) {
        let context = persistenceController.container.viewContext
       
        // 1. Create Managed Object
        gameEntity = GameEntity(context: context)
        
        
        // 2. Configure Managed Object
        gameEntity!.game_id = GameEntity.createUniqueGameID(context: context)
        gameEntity!.location = MyLocationManager.playerLocation
        gameEntity!.player_name = GameRepository.playerName
        // 3. Save the Context
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func insertGameRoundResultIntoDB(persistenceController: PersistenceController, round_no: Int32, is_bust: Bool, is_tie: Bool, player_score: Int32, dealer_score: Int32) -> Bool {
        let context = persistenceController.container.viewContext
        if round_no == 1 {
            //one game object can belong to multiple rounds so init only one time for one game
            // if round is 1 it mean user has complete one round so game object has to init before stroing round
            createNewGameEntity(persistenceController: persistenceController)
        }
        
        
        // 1. Create Managed Object of RoundEntity
        let roundEntity = RoundEntity(context: context)
        
        // 2. Configure Managed Object
        roundEntity.game_id = gameEntity?.game_id ?? 1
        roundEntity.round_id = round_no
        roundEntity.is_bust = is_bust
        roundEntity.is_tie = is_tie
        roundEntity.player_score = player_score
        roundEntity.dealer_score = dealer_score
        
        // 3. Establish the relationship between GameEntity and RoundEntity
        gameEntity?.addToRound_relationship(roundEntity)
        // 4. Save the Context
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
        return true
    }
    
}
