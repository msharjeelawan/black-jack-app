//
//  GameEntityExtension.swift
//  Black Jack
//
//  Created by user252256 on 1/3/24.
//

import Foundation
import CoreData

extension GameEntity {
    static func createUniqueGameID(context: NSManagedObjectContext) -> Int32 {
            let fetchRequest: NSFetchRequest<GameEntity> = GameEntity.fetchRequest()
            fetchRequest.sortDescriptors = [NSSortDescriptor(key: "game_id", ascending: false)]
            fetchRequest.fetchLimit = 1

            do {
                let lastGame = try context.fetch(fetchRequest).first
                let newGameID = (lastGame?.game_id ?? 0) + 1
                return newGameID
            } catch {
                print("Error fetching last game: \(error)")
                return 1 // Default to 1 if an error occurs
            }
        }
    
    static func getAllGameResults(context: NSManagedObjectContext) -> [GameEntity] {
        let fetchRequest: NSFetchRequest<GameEntity> = GameEntity.fetchRequest()
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "game_id", ascending: false)]
        // Include the rounds relationship in the fetch request
        //fetchRequest.predicate = NSPredicate(format: "game_id == %@", argumentArray: [gameID])

        fetchRequest.relationshipKeyPathsForPrefetching = ["round_relationship"]

        do{
            // Fetch games with their associated rounds
            let games = try context.fetch(fetchRequest)
            return games
        }catch {
            print("Error fetching games with rounds: \(error.localizedDescription)")
            return []
        }
    }
    
    static func removeAllResults() {
        let persistentContainer = PersistenceController.shared.container
        let storeURL = persistentContainer.persistentStoreDescriptions.first?.url

        do {
            try persistentContainer.persistentStoreCoordinator.destroyPersistentStore(at: storeURL!, ofType: NSSQLiteStoreType, options: nil)
            try persistentContainer.persistentStoreCoordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: storeURL, options: nil)
        } catch {
            print("Error resetting persistent store: \(error)")
        }
    }
}
