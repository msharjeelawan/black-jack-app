//
//  ResultViewModel.swift
//  Black Jack
//
//  Created by user252256 on 1/4/24.
//

import Foundation

class ResultViewModel: ObservableObject {
    
    var persistenceController: PersistenceController
    let resultRepository: ResultRepository = ResultRepository()
    
    init() {
        persistenceController = PersistenceController.shared
    }
    
    func getAllGameResults() -> [GameEntity] {
       return resultRepository.getAllGameResult(persistenceController: persistenceController)
    }
    
    func countWinLossTieOfAllRounds(game: GameEntity) -> [String:Int] {
        return resultRepository.calculateRounds(of: game)
    }
    
}
