//
//  GameViewModel.swift
//  Black Jack App
//
//  Created by user252256 on 12/27/23.
//

import Foundation
import CoreLocation
import UIKit

class GameViewModel : ObservableObject {

    var isPlayerStand = false
    var isDealerStand = false
    var playerTotalNumbers = 0
    var dealerTotalNumbers = 0
    var round = 0
    var isBust = false
    var isTie = false
    @Published var showToast = false
    @Published var message = ""
    let player = AppConstants.PlayerType.player
    let dealer = AppConstants.PlayerType.dealer
    @Published var deckList : [GameCard] = []
    @Published var playerList : [GameCard] = []
    @Published var dealerList : [GameCard] = []
    @Published var drawList : [GameCard] = []
    var gameRepository : GameRepository?  = GameRepository()
    var drawCardResponse: DrawCardResponse?
    var persistenceController: PersistenceController
    var playerLocation = ""
    
    init(){
        persistenceController = PersistenceController.shared
        
        Task {
            try await startNewGame()
//            print("game repository is creating")
//            gameRepository = try await GameRepository()
//            print("game repository has created")
//            drawCardResponse = try await gameRepository?.drawAllCards()
//            print("game repository draw card")
//            
//            loadDeckWithCard()
//            
//            print("game repository done with length: \(drawCardResponse!.cards.count)")
        }
        
    }
    
    func startNewGame() async throws {
        round = 1
        //create new deck from api
        try await gameRepository?.createNewDeck()
        //draw all cards from deck in single api call, instead one by one
        //drawCardResponse = try await gameRepository?.drawAllCards()
       // loadDeckWithCard()
        loadDeckWithFakeCards()
    }
    
    func makeCardFromJson() async throws -> GameCard {
        drawCardResponse = try await gameRepository?.drawCard()
        if let cards = drawCardResponse?.cards {
            for card in cards {
                
                if let cardNo = cardValueToInt(card.value) {
                    let cardValue = cardValue(fromCode: card.code)
                    if let cardImage = UIImage(named: cardValue) {
                    
                        return GameCard(no: cardNo, image: cardImage )
                    }
                    
                }
            }
        }
        return GameCard(no: 0, image: UIImage(named: "back")! )
    }
     
    func loadDeckWithFakeCards() {
        for i in 1...104 {
            deckList.append(GameCard(no: 0, image: UIImage(named: "back")! ))
        }
    }
    
//    func loadDeckWithCard() {
//        if let cards = drawCardResponse?.cards {
//            for card in cards {
//                
//                if let cardNo = cardValueToInt(card.value) {
//                    let cardValue = cardValue(fromCode: card.code)
//                    if let cardImage = UIImage(named: cardValue) {
//                        deckList.append(GameCard(no: cardNo, image: cardImage ))
//
//                    }
//                    //deckList.append(CardView(imageURL: URL(string: card.image)!,no: cardValue))
//                }
//            }
//        }
//    }
    
    func cardValueToInt(_ cardValue: String) -> Int? {
        let valueString = cardValue // Extract the first character of the card string

        if let intValue = Int(valueString) {
            // If the first character is a number, return its integer value
            return intValue
        } else {
            // If the first character is a letter (e.g., K, Q, A, J), map it to its corresponding value
            switch valueString {
            case "KING", "QUEEN", "JACK":
                return 10
            case "ACE":
                return 11 // You might want to handle the Ace differently based on the game rules
            default:
                return nil // Invalid card string
            }
        }
    }
    
    
    func cardValue(fromCode code: String) -> String {
        let valueString = code.dropLast()
        
        switch valueString {
        case "0"..."9":
            return String(valueString)
        case "J":
            return "JACK"
        case "Q":
            return "QUEEN"
        case "K":
            return "KING"
        case "A":
            return "ACE"
        default:
            return "Invalid Card Code"
        }
    }
    
    
    //draw card or hit
    func drawCard(playerType:String) async throws {

        if deckList.count < 64 {
            showMessage(msg: "Deck size drop 64. So it is reseting.")
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                self.resetAndShuffleToDeck()
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.showMessage(msg: "Now Player's turn due to Deck Reset.")
                }
            }
            return
        }
        
        //check if player has stand and try to draw card again then will fail
        if isPlayerStand == true && playerType == player{
            return
        }
        
        //let randomNumer = Int.random(in: 0..<deckList.count) //generate random number
       //let card = deckList[randomNumer] //get card of specific index
      
        let card = try await makeCardFromJson()
        
        //for player round
        if isPlayerStand == false && playerType == player {
            playerList.append(card) //add card at the end in player list
            deckList.removeLast() //now remove card from sample fake deck
            calculateNumberOfCards(playerType: playerType) //on every hit calculate result for checking if point cross 21 then bust
        }else if (isDealerStand == false && playerType == dealer) {
            print("dealer stand")
            //for dealer round
            dealerList.append(card)
            deckList.removeLast()
            calculateNumberOfCards(playerType: playerType)
        }
        
    }
    
    func standPlayer() {
        //player can stand only if not stand already
        if isPlayerStand == false {
            isPlayerStand = true
            
            //show message of player stand
            showMessage(msg: "Now dealer's turn")
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                // turn transfer to dealer
                self.startDealerHit()
            }
       
        }else{
            //player already stand, show alert
            showMessage(msg: "Player already stand")
        }
    }
    
    func startDealerHit() {
        //to avoid from dealer bust, draw card only if dealer has 17 or less numbers
        let dealerDrawLimit = 17
        if dealerTotalNumbers <= dealerDrawLimit {
            //add delay of 1 second
            print("dealer total numbers \(dealerTotalNumbers)")
            print("is dealer stand: \(isDealerStand)")
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                
                Task {
                    try await self.drawCard(playerType : AppConstants.PlayerType.dealer)
                    
                    
                    if self.dealerTotalNumbers <= dealerDrawLimit  && self.isBust == false {
                        self.startDealerHit()
                    }else if self.isBust == true {
                        //clear is bust state
                        self.isBust = false
                    }
                    
                    //check if dealer has not bust then stand the dealer
                    if self.dealerTotalNumbers > 17 && self.dealerTotalNumbers <= 21 {
                        self.standDealer()
                        print("delar turn complete now dealer stand")
                    }
                }
            }
        }
    }
    
    func standDealer() {
        if isDealerStand == false {
            isDealerStand = true
            
            //show message of generating result
            showMessage(msg: "Comparing hand's")
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                //now compare result and again turn transfer to player
                self.compareResult()
            }
        }
    }
    
    func calculateNumberOfCards(playerType :String) {
        var cardNumbers = 0
        if playerType == player {
            for card in playerList {
                cardNumbers += card.no
                print(card.no)
            }
            playerTotalNumbers = cardNumbers
            checkBust(of: player)
        }else if playerType == dealer {
            for card in dealerList {
                cardNumbers += card.no
                print(card.no)
            }
            dealerTotalNumbers = cardNumbers
            checkBust(of: dealer)
        }
    }
    
    func resetAndShuffleToDeck() {
        Task {
            try await gameRepository?.shuffleDeck()
        }
        
        //transfer used cards from draw list to deck list
        let fakeCard = deckList[1]
        for card in drawList {
            deckList.append(fakeCard)
        }
        //transfer player cards from player list to deck list if available
        for card in playerList {
            deckList.append(fakeCard)
        }
        //transfer dealer cards from dealer list to deck list if available
        for card in dealerList {
            deckList.append(fakeCard)
        }
        //now remove all cards from draw list, player list & dealer list
        drawList.removeAll()
        playerList.removeAll()
        dealerList.removeAll()
        //now shuffle the deck list
       // deckList.shuffle()
        
        //clear player and dealer hand
        resetRound()
    }
    
    func resetRound() {
        isBust = false
        playerTotalNumbers = 0
        dealerTotalNumbers = 0
        
    }
    
    func checkBust(of:String) {
        if of == player && playerTotalNumbers > 21 {
            // bust by player, dealer win this round
            isBust = true
            showMessage(msg: "Player bust. Dealer Win")
            //store this round result in local database
            storeRoundResultIntoDB()
            //move cards of only player to used card list
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                let hasCardClear = self.clearCardsOfPlayer()
                
                //start new round, show notification of new round
                if hasCardClear {
                    self.startNextRound()
                }
            }
            
            
        }else if of == dealer && dealerTotalNumbers > 21 {
            // bust by dealer, player win this round
            isBust = true
            showMessage(msg: "Dealer bust. Player Win")
            //store this round result in local database
            storeRoundResultIntoDB()
            //move cards of player and dealer to used card list
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                let hasPlayerCardClear = self.clearCardsOfDealer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    let hasDealerCardClear = self.clearCardsOfPlayer()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        //start new round, show notification of new round
                        if hasPlayerCardClear && hasDealerCardClear {
                            self.startNextRound()
                        }
                    }
                    
                }
            }
           
           
        }
    }
    
    //use core data to store game result
    func storeRoundResultIntoDB() {
        
        var _ = gameRepository?.insertGameRoundResultIntoDB(persistenceController: persistenceController, round_no: Int32(round), is_bust: isBust, is_tie: isTie, player_score: Int32(playerTotalNumbers), dealer_score: Int32(dealerTotalNumbers))
    }
    
    func clearCardsOfPlayer() -> Bool {
        //clear player cards
        for (_, card) in playerList.enumerated(){
            drawList.append(card)
        }
        playerList.removeAll()
        
        return playerList.isEmpty
    }
    
    func clearCardsOfDealer()  -> Bool {
        //clear dealear cards
        for (_, card) in dealerList.enumerated(){
            drawList.append(card)
        }
        dealerList.removeAll()
        
        return dealerList.isEmpty
    }
    
    func compareResult() {
        if playerTotalNumbers > dealerTotalNumbers {
            //player win this round, show notification
            showMessage(msg: "Player Win")
        }else if dealerTotalNumbers > playerTotalNumbers {
            //dealer win this round, show notification
            showMessage(msg: "Dealer Win")
        }else if playerTotalNumbers == dealerTotalNumbers {
            // this round has tie, show notification
            showMessage(msg: "Tie")
            isTie = true
        }
        //store result of game round in local database
        storeRoundResultIntoDB()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            //start next round
            self.startNextRound()
        }
    }
    
    func startNextRound() {
        round = round + 1
        //clear stand mode of player and dealer
        isPlayerStand = false
        isDealerStand = false
        isBust = false
        isTie = false
        playerTotalNumbers = 0
        dealerTotalNumbers = 0
        //clear player and dealer card list
        var _ = clearCardsOfPlayer()
        var _ = clearCardsOfDealer()
        
        //next round message
        showMessage(msg: "Next Round")
    }

    func showMessage(msg: String) {
        message = msg
        showToast = true
    }

    func clearAllCards() {
        playerList.removeAll()
        dealerList.removeAll()
        deckList.removeAll()
        drawList.removeAll()
        playerTotalNumbers = 0
        dealerTotalNumbers = 0
        isPlayerStand = false
        isDealerStand = false
        isBust = false
        isTie = false
    }
}
