//
//  GameService.swift
//  Black Jack App
//
//  Created by user252256 on 12/29/23.
//

import Foundation


class GameService {
    
    var deckResponse:NewDeckResponse?
    
    func createNewDeck() async throws {
        let newDeckUrl = URL(string: AppConstants.newDeckApi)! //creat url object from sting url
        // let urlComponent = URLComponents(url: newDeckUrl, resolvingAgainstBaseURL: true) //url compoment object will check our url
        
        
        //if provied url to urlcomponent is okay then we will retrieve url request object
        //        guard let url = urlComponent?.url else {
        //            DispatchQueue.main.async {
        //                completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
        //                          return
        //            }
        //
        //        }
        
        do {
            let response = try await sendApiRequest(on: newDeckUrl)
            let decoder = JSONDecoder()
            deckResponse = try decoder.decode(NewDeckResponse.self, from: response)
            print("game deck id \(deckResponse!.deckId)")
        }catch let decodingError as DecodingError {
            print("game decoding exception")
            throw AppConstants.NetworkError.decodingFailed(decodingError)
        }
        
        //send api request
//        URLSession.shared.dataTask(with: url) { data, response, error in
//            if let error = error {
//                DispatchQueue.main.async {
//                    completion(.failure(error))
//                }
//                return
//
//            }
//
//            if let data = data {
//                do {
//
//                }catch{
//                    let decoder = JSONDecoder()
//
//                }
//            }
//
//        }
        
        
        
    }
    
    
    func drawCard() async throws -> DrawCardResponse{
        
        
        guard let deckId = deckResponse?.deckId else{
            throw AppConstants.NetworkError.deckResponseError(NSError(domain: "Deck Response is null", code: 0, userInfo: nil))
        }
        
        let drawCardUrl = URL(string: AppConstants.getDrawCardApi(deckId: deckId))! //creat url object from sting url
        do {
            let response = try await sendApiRequest(on: drawCardUrl)
            let decoder = JSONDecoder()
            let drawCardResponse = try decoder.decode(DrawCardResponse.self, from: response)
            return drawCardResponse
        }catch let decodingError as DecodingError {
            print("game cards decoding exception")
            throw AppConstants.NetworkError.decodingFailed(decodingError)
        }
    }
    
    func shuffleCard() async throws -> ShuffleDeckResponse{
    
        guard let deckId = deckResponse?.deckId else{
            throw AppConstants.NetworkError.deckResponseError(NSError(domain: "Deck Response is null", code: 0, userInfo: nil))
        }
        
        let shuffleCardUrl = URL(string: AppConstants.getShuffleCardApi(deckId: deckId))! //creat url object from sting url
        do {
            let response = try await sendApiRequest(on: shuffleCardUrl)
            let decoder = JSONDecoder()
            let shuffleDeckResponse = try decoder.decode(ShuffleDeckResponse.self, from: response)
            return shuffleDeckResponse
        }catch let decodingError as DecodingError {
            print("game cards decoding exception")
            throw AppConstants.NetworkError.decodingFailed(decodingError)
        }
    }
    
    func sendApiRequest(on: URL) async throws -> Data {
        
        do {
            let (data,response) = try await URLSession.shared.data(from: on)
            
            //if response can cast into HTTPURLReponse
            guard let httpResponse = response as? HTTPURLResponse else {
                throw AppConstants.NetworkError.requestFailed(NSError(domain: "Invalid Response", code: 0, userInfo: nil))
            }
            
            //check if reponse is between 200 to 299, then read data
            if httpResponse.statusCode == 200 || httpResponse.statusCode > 200  && httpResponse.statusCode < 300 {
                return data
            }else{
                throw AppConstants.NetworkError.invalidResponse(httpResponse.statusCode)
            }
           
        }catch {
            print("game api call exception exception")
            throw AppConstants.NetworkError.requestFailed(NSError(domain: "Invalid URL", code: 0, userInfo: nil))
        }
        
    }
}
