//
//  DrawAllCardResponse.swift
//  Black Jack App
//
//  Created by user252256 on 12/30/23.
//

import Foundation


struct DrawCardResponse: Codable {
    let success: Bool
    let deckId: String
    let cards: [DeckCard]
    
    enum CodingKeys: String, CodingKey {
        case success, deckId = "deck_id", cards
    }
}


struct CardImages: Codable {
    let svg: String
    let png: String
    enum CodingKeys: String, CodingKey {
        case svg, png
    }
}


struct DeckCard: Codable {
    let code: String
    let image: String
    let images: CardImages
    let value: String
    let suit: String
    
    enum CodingKeys: String, CodingKey {
        case code, image, images, value, suit
    }
}
