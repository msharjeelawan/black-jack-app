//
//  ShuffleDeckResponse.swift
//  Black Jack
//
//  Created by user252256 on 1/30/24.
//

import Foundation

struct ShuffleDeckResponse: Codable {
    let success: Bool
    let deckId: String
    let remaining: Int
    let shuffled: Bool
    
    enum CodingKeys: String, CodingKey {
            case success
            case deckId = "deck_id"
            case remaining
            case shuffled
    }
    
}
