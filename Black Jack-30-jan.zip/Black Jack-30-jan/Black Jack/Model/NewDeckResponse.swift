//
//  NewDeckResponseModel.swift
//  Black Jack App
//
//  Created by user252256 on 12/29/23.
//

import Foundation

struct NewDeckResponse: Codable {
    let success: Bool
    let deckId: String
    let remaining: Int
    let shuffled: Bool
    
    enum CodingKeys: String, CodingKey {
            case success
            case deckId = "deck_id"
            case remaining
            case shuffled
    }
    
}
