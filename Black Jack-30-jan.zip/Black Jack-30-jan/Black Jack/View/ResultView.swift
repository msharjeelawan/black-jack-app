//
//  ResultView.swift
//  Black Jack
//
//  Created by user252256 on 1/4/24.
//

import SwiftUI
import Charts
import DGCharts


struct ResultView: View {
    let resultViewModel = ResultViewModel()
    @State private var clearResults = false
    
    var body: some View {
        NavigationView {
            ScrollView   {
                VStack {
                  
                    ForEach(resultViewModel.getAllGameResults()) { gameEntity in
                        
                        let result = resultViewModel.countWinLossTieOfAllRounds(game: gameEntity)
                        
                        NavigationLink(destination: 
                                        VStack {
                            Text("Location: \(gameEntity.location ?? "")")
                            Text("Player: \(gameEntity.player_name ?? "")")
                            FormatResultView(result: result)
                        }.background(Color.green).navigationBarTitle("Game No: \(result["game_no"] ?? 0)")
                                       
                        ) {
                            ResultItem(gameResult: result, gameEntity: gameEntity)
                        }.navigationBarTitle("Results")
                        
                    }
                    if resultViewModel.getAllGameResults().count == 0 {
                        Text("No Result Found.").font(.system(size: 20, weight: .bold)).frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
                    }
                }.navigationBarItems(trailing:    Button("Clear") {
                    clearResults = true
                }.padding(.trailing,25).padding(.top,5) .foregroundColor(.black)
                    .alert("Alert", isPresented: $clearResults, actions: {
              
                    
                    Button("Clear", action:  {
    
                        GameEntity.removeAllResults()
                        
                       
                    })
                    Button("Cancel", role: .cancel, action: {})
                    
                }, message: {
                    Text("Do you want to delete all Game records.")
                })) .navigationBarTitle("Results", displayMode: .inline)
            }.background(Color.green)
        }
    }
}

#Preview {
    ResultView()
}


struct ResultItem: View {
    var gameResult: [String:Int]
    var gameEntity: GameEntity
    
    var body: some View {
        HStack(alignment:.top,spacing: UIScreen.main.bounds.width*0.1) {
            VStack(alignment:.leading) {
                Text("Game No: \(gameResult["game_no"] ?? 0)")
                Text("Total Rounds: \(gameResult["rounds"] ?? 0)")
                Text("Location: \(gameEntity.location ?? "")")
            }
            VStack(alignment:.trailing) {
                Text("Player Win: \(gameResult["win"] ?? 0)")
                Text("Player Loss: \(gameResult["loss"] ?? 0)")
                Text("Tie: \(gameResult["tie"] ?? 0)")
               
            }
            
            
            // Add other details as needed
        }
        .padding()
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
        .background(Color.black)
        .cornerRadius(10)
        .foregroundColor(.green)
        .padding()
        
    }
}


struct FormatResultView: UIViewRepresentable {
    var result: [String:Int]
    
    
    func makeUIView(context: Context) -> PieChartView {
        let chartView = PieChartView()
         updateUIView(chartView, context: context)
         return chartView
     }
    
    func updateUIView(_ chart: DGCharts.PieChartView, context: Context) {
        var entries: [PieChartDataEntry] = []
        
        result.forEach { (key,value) in
            if key != "game_no" {
                entries.append(PieChartDataEntry(value: Double(value), label: key))
            }
            
        }
        
        let dataSet = PieChartDataSet(entries: entries, label: "Round Results")
        
        dataSet.colors = ChartColorTemplates.joyful()
        let data = PieChartData(dataSet: dataSet)
        
        chart.data = data
    }
    
   
}
