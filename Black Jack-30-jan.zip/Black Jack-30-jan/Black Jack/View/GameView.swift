//
//  GameView.swift
//  Black Jack App
//
//  Created by user252256 on 12/24/23.
//

import SwiftUI
import SimpleToast
import CoreLocation

struct Card: Identifiable {
    var id = UUID()
    var color: Color
}

struct GameCard: View {
    let no: Int
    let image: UIImage
    
    var body: some View {
        VStack {
            Image(uiImage: image)
            .cornerRadius(10)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1))
            .frame(width: 150, height: 120)
        }
    }
}


//struct CardView: View {
//    var imageURL: URL
//    var no: Int
//    
//    var body: some View {
//        VStack {
//            AsyncImage(url: imageURL) { phase in
//                switch phase {
//                case .empty:
//                    // Placeholder or loading view
//                    Color.gray
//                case .success(let image):
//                    image
//                        .resizable()
//                        .aspectRatio(contentMode: .fill)
//                case .failure:
//                    // Placeholder or error view
//                    Image(systemName: "photo")
//                        .resizable()
//                        .aspectRatio(contentMode: .fit)
//                        .foregroundColor(.red)
//                @unknown default:
//                    // Placeholder or default view
//                    Color.gray
//                }
//            }
//            .cornerRadius(10)
//            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1))
//            .frame(width: 150, height: 120)
//        }
//    }
//}


struct GameView: View {
   
    @StateObject var gameViewModel: GameViewModel = GameViewModel()
    
    private let toastOptions = SimpleToastOptions(
        alignment: .center,
        hideAfter: 2
    )
    @State private var startNewGame = false
    
    var body: some View {
        
        VStack(spacing:0) {
            HStack(){
                Spacer()
                Button("New Game") {
                    startNewGame = true
                }.padding(.trailing,25).padding(.top,15) .foregroundColor(.black)
                    .alert("Alert", isPresented: $startNewGame, actions: {
              
                    
                    Button("Start Game", action:  {
    
                        Task {
                            do {
                                try await gameViewModel.startNewGame()
                               
                            } catch {
                                
                            }
                            
                        }
                        
                        gameViewModel.clearAllCards()
                    })
                    Button("Cancel", role: .cancel, action: {})
                    
                }, message: {
                    Text("Do you want to start a new Game.")
                })
            }
            
            //this stack will use for dealear cards
            HStack {
                
                //                    ForEach(Array(cards.enumerated()), id: \.element.id ) { index, card in
                //                        if index == 0 {
                //                            CardView(color: card.color)
                //                                .offset( x: 10, y: -100
                //                                ).rotationEffect(.degrees(90))
                //                       }
                //                    }
                
                
                
                ZStack {
                    //it is stack of dealear cards
                    if gameViewModel.dealerList.count > 0 {
                        ForEach(Array(gameViewModel.dealerList.enumerated()), id: \.offset ) { index, card in
                          //  if index < 5 {
                            
                            card.offset( x: CGFloat(index) * 30, y: 10)
                          //  }
                        }
                    }
                }
            }.frame(height:UIScreen.main.bounds.height*0.3).padding(.trailing,100)
            
            
            // Display dealer's hand (one card hidden initially)
            
            Text("Dealer Hand: \(gameViewModel.dealerTotalNumbers)")
            HStack {
                //it is stack of used cards
                ZStack {
                    if gameViewModel.drawList.count > 0 {
                        ForEach(Array(gameViewModel.drawList.enumerated()), id: \.offset) { index, card in
                            
                            card.offset( x:CGFloat(index) * -10 + (UIScreen.main.bounds.width * -0.1),  y: 0
                                )
                        }
                        
                    }
                    
                }.frame(width:UIScreen.main.bounds.width*0.15)
                
                ZStack {
                    HStack {
                        Text(" \(gameViewModel.drawList.count)")
                        Spacer()
                        Text(" BlackJack").font(.system(size: 20, weight: .bold))
                        Spacer()
                        Text(" \(gameViewModel.deckList.count)")
                    }.frame(width:UIScreen.main.bounds.width*0.6)
                    
                }
               
                
                ZStack {
                    
                    //it's a deck or stack of new cards
                    if gameViewModel.deckList.count > 0 {
                        ForEach(Array(gameViewModel.deckList.enumerated()), id: \.offset) { index, card in
                            card.offset( x: CGFloat(index) * 10 + (UIScreen.main.bounds.width * 0.1), y: 0
                            )
                        }
                    }
                }.frame(width:UIScreen.main.bounds.width*0.15)
                
            }.frame(maxHeight: UIScreen.main.bounds.height*0.2)
            
            Text("Player Hand: \(gameViewModel.playerTotalNumbers)")
            // Display player's hand
            
            
            VStack() {
                
                ZStack() {
                    if gameViewModel.playerList.count > 0 {
                        ForEach(Array(gameViewModel.playerList.enumerated()), id: \.offset ) { index, card in
                            if index < 5 {
                                card.offset( x: CGFloat(index) * 30, y: 10)
                                
                            }
                        }
                    }
                }
            }.frame(width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height*0.27).padding(.trailing,100).padding(.bottom,20)
            
            HStack(alignment: .center,spacing: 80) {
                
                Button("Hit") {
                    Task {
                        try await gameViewModel.drawCard(playerType: AppConstants.PlayerType.player)
                    }
                    
                       
                    
                }.foregroundColor(.black).font(.system(size: 18, weight: .bold))
                
                Button("Stand") {
                   gameViewModel.standPlayer()
                    
                } .foregroundColor(.black).font(.system(size: 18, weight: .bold))
                
                //Text("Game Result:\(gameViewModel.gameResult)")
                            }
            Spacer().frame(height:UIScreen.main.bounds.height*0.04)
            
            
            
        }.frame( width: UIScreen.main.bounds.width,
                 height: UIScreen.main.bounds.height)
        .background(Color.green)
        //Image("game-bg")
        //.resizable()
        //.scaledToFill()
        //.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        .simpleToast(isPresented: $gameViewModel.showToast, options: toastOptions) {
            Label("\(gameViewModel.message)", systemImage: "exclamationmark.triangle")
                .padding()
                .background(Color.red.opacity(0.8))
                .foregroundColor(Color.white)
                .cornerRadius(10)
                .padding(.bottom)
        }
                
        
        
    }
    
}

#Preview {
    GameView()
}

