//
//  HomeView.swift
//  Black Jack
//
//  Created by user252256 on 1/5/24.
//

import SwiftUI
import CoreLocation
import SimpleToast

struct HomeView: View {
    
    @State var showToast = false
    @State var message = ""
    private let toastOptions = SimpleToastOptions(
        alignment: .center,
        hideAfter: 3
    )
    @State private var isEditingName = false
    @State private var shouldNavigate = false
    @State private var playerName = ""

    var body: some View {
        @ObservedObject var locationManager = MyLocationManager()

        
        NavigationStack {
            ZStack {
                Color.green
                    .edgesIgnoringSafeArea(.all)
                
                VStack() {
                    Spacer()
                    
                    if !locationManager.locationPermissionGranted {
                       
                        Button("New Game") {
                            isEditingName = true
                            MyLocationManager.playerLocation = "Fake location"
                        } .frame(maxWidth: .infinity)
                            .foregroundColor(.green)
                            .padding()
                            .background(Color.black)
                            .cornerRadius(10)
                            .alert("Player Name", isPresented: $isEditingName, actions: {
                            TextField("Name", text: $playerName)
                            
                            Button("Start Game", action: {
                                if playerName.isEmpty == false {
                                    GameRepository.playerName = playerName
                                    shouldNavigate = true
                                }else{
                                    message = "You didn't name name."
                                    showToast = true
                                }
                                
                                   
                            })
                            Button("Cancel", role: .cancel, action: {})
                            
                        }, message: {
                            Text("Please enter your name.")
                        })
                        
                    }else {
                        Button("New Game"){
                            message = "Location Permision is required to play a Game. Please Give Location Permission from setting."
                            showToast = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                showToast = false
                                openSettings()
                            }
                            
                        }.frame(maxWidth: .infinity)
                            .foregroundColor(.green)
                            .padding()
                            .background(Color.black)
                            .cornerRadius(10)
                    }
                        
                        
                    NavigationLink("View Result",destination: ResultView())
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.green)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                    Spacer()
                    
                }.padding()
                .navigationBarTitle("Home", displayMode: .inline)
                .simpleToast(isPresented: $showToast, options: toastOptions) {
                    Label("\(message)", systemImage: "exclamationmark.triangle")
                        .padding()
                        .background(Color.red.opacity(0.8))
                        .foregroundColor(Color.white)
                        .cornerRadius(10)
                        .padding(.bottom)
                }
                .navigationDestination(isPresented: $shouldNavigate) {
                    GameView()
                    }
                
            }
            
        }
    }
    
    
    private func openSettings() {
        guard let settingsURL = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(settingsURL)
    }
    
}

#Preview {
    HomeView()
}
