//
//  Black_JackApp.swift
//  Black Jack
//
//  Created by user252256 on 1/2/24.
//

import SwiftUI

@main
struct Black_JackApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            HomeView()
            //   GameView()
//            ContentView()
//                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
