//
//  MyLocationManager.swift
//  Black Jack
//
//  Created by user252256 on 1/6/24.
//

import Foundation
import CoreLocation

class MyLocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()

    @Published var userLocation: CLLocationCoordinate2D?
    @Published var locationPermissionGranted: Bool = false
    static var playerLocation = "Cupertino, California, USA"
    
    override init() {
        super.init()
        setupLocationManager()
    }

    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest

        // Check for location services authorization
        if CLLocationManager.locationServicesEnabled() {
            print("location service enable")
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        } else {
            // Handle case where location services are not enabled
            print("Location services are not enabled")
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("location changed")
        guard let location = locations.last?.coordinate else { return }

        // Update the userLocation
        userLocation = location
        // Update the locationPermissionGranted
        locationPermissionGranted = true
        //convert latitude and longitude into address
        getAddressFromCoordinate(location)
        
        
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // Handle location error
        print("Location error: \(error.localizedDescription)")
    }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        // Handle authorization status changes
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            // Handle authorized status
            locationManager.startUpdatingLocation()
        case .denied, .restricted:
            // Handle denied or restricted status
            print("Location access denied")
        case .notDetermined:
            // Handle not determined status
            locationManager.requestWhenInUseAuthorization()
        @unknown default:
            break
        }
    }
    
    func getAddressFromCoordinate(_ coordinate: CLLocationCoordinate2D) {
        let geocoder = CLGeocoder()
        
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            if error != nil {
                // print("Reverse geocoding error: \(error.localizedDescription)")
                return
            }
            
            if let placemark = placemarks?.first {
                // Extract relevant address components
                if let street = placemark.thoroughfare,
                   let city = placemark.locality,
                   let state = placemark.administrativeArea,
                   let country = placemark.country {
                    MyLocationManager.playerLocation = "\(street), \(city), \(state), \(country)"
                } else {
                    print("Unable to extract address components from placemark")
                }
            } else {
                print("No address found for the given coordinates")
            }
        }
    }
    
}
