//
//  AppConstants.swift
//  Black Jack App
//
//  Created by user252256 on 12/27/23.
//

import Foundation

enum AppConstants {
    
    static let deckId = ""
    static let newDeckApi = "https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=2"
    //static let drawCardApi = "https://www.deckofcardsapi.com/api/deck/\(deckId)/draw/?count=104"
    
    static func getDrawCardApi(deckId: String) -> String {
        return "https://www.deckofcardsapi.com/api/deck/\(deckId)/draw/?count=1"
    }
    
    static func getShuffleCardApi(deckId: String) -> String {
        return "https://www.deckofcardsapi.com/api/deck/\(deckId)/shuffle/?remaining=true"
    }
    
    enum PlayerType {
       static let player = "player"
       static let dealer = "dealer"
    }
    
    enum NetworkError : Error {
        case requestFailed(Error)
        case invalidResponse(Int)
        case decodingFailed(Error)
        case deckResponseError(Error)
    }
}
