//
//  GameEntity+CoreDataProperties.swift
//  Black Jack
//
//  Created by user252256 on 1/3/24.
//
//

import Foundation
import CoreData


extension MyGameEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<GameEntity> {
        return NSFetchRequest<GameEntity>(entityName: "GameEntity")
    }

    @NSManaged public var game_id: Int32
    @NSManaged public var round_relationship: NSSet?

}

// MARK: Generated accessors for round_relationship
extension MyGameEntity {

    @objc(addRound_relationshipObject:)
    @NSManaged public func addToRound_relationship(_ value: RoundEntity)

    @objc(removeRound_relationshipObject:)
    @NSManaged public func removeFromRound_relationship(_ value: RoundEntity)

    @objc(addRound_relationship:)
    @NSManaged public func addToRound_relationship(_ values: NSSet)

    @objc(removeRound_relationship:)
    @NSManaged public func removeFromRound_relationship(_ values: NSSet)

}

extension GameEntity : Identifiable {

}
